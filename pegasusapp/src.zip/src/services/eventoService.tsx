import { type Evento, TipoDestinatario } from "../models/evento"
import type { IntegrantesEventos } from "../models/integrantesEventos"
import type { Usuario } from "../models/usuario"
import { CONFIG } from "./config"


export const eventoService = {
  // Obtener todos los eventos filtrados por perfil
  async getEventos(idPerfil: number): Promise<Evento[]> {
    try {
      const response = await fetch(`${CONFIG.API_BASE_URL}/Evento/GetEventosForCombo`)

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`)
      }

      const eventos: Evento[] = await response.json()

      // Filtrar eventos según el perfil del usuario
      return filtrarEventosPorPerfil(eventos, idPerfil)
    } catch (error) {
      throw error
    }
  },

  // Obtener evento por ID
  async getEventoById(id: number): Promise<Evento> {
    try {
      const response = await fetch(`${CONFIG.API_BASE_URL}/Evento/GetById?id=${id}`)

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`)
      }

      return await response.json()
    } catch (error) {
      throw error
    }
  },

  // Crear evento
  async createEvento(evento: Partial<Evento>): Promise<Evento> {
    try {
      const response = await fetch(`${CONFIG.API_BASE_URL}/Evento/CreateEvento`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          nombre: evento.nombre,
          descripcion: evento.descripcion,
          fecha: evento.fecha,
          requiereConfirmacion: evento.requiereConfirmacion || false,
          tipoDestinatario: evento.tipoDestinatario || TipoDestinatario.Ambos,
        }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Error ${response.status}: ${errorText}`)
      }

      const eventoCreado = await response.json()

      // Enviar correos informativos
      await this.enviarCorreosInformativos(eventoCreado)

      // Si requiere confirmación, crear registros de integrantes
      if (evento.requiereConfirmacion) {
        await this.guardarIntegrantes(eventoCreado.id, evento.tipoDestinatario || TipoDestinatario.Ambos)
      }

      return eventoCreado
    } catch (error) {
      throw error
    }
  },

  // Actualizar evento
  async updateEvento(evento: Evento): Promise<Evento> {
    try {
      const response = await fetch(`${CONFIG.API_BASE_URL}/Evento/UpdateEvento`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: evento.id,
          nombre: evento.nombre,
          descripcion: evento.descripcion,
          fecha: evento.fecha,
          requiereConfirmacion: evento.requiereConfirmacion || false,
          tipoDestinatario: evento.tipoDestinatario || TipoDestinatario.Ambos,
        }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Error ${response.status}: ${errorText}`)
      }

      const eventoActualizado = await response.json()

      // Enviar correos informativos sobre la actualización
      await this.enviarCorreosInformativos(eventoActualizado)

      return eventoActualizado
    } catch (error) {
      throw error
    }
  },

  // Eliminar evento
  async deleteEvento(id: number): Promise<void> {
    try {
      // Primero eliminar integrantes del evento
      await this.eliminarIntegrantesEvento(id)

      // Luego eliminar el evento
       const response = await fetch(`${CONFIG.API_BASE_URL}/Evento/DeleteEvento/${id}`, {
      method: 'DELETE',
    });

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Error ${response.status}: ${errorText}`)
      }
    } catch (error) {
      throw error
    }
  },

  // Obtener integrantes de un evento
  async getIntegrantesEvento(eventoId: number): Promise<IntegrantesEventos[]> {
    try {
      const queryParam = encodeURIComponent(`x=>x.id_evento==${eventoId}`)
      const response = await fetch(`${CONFIG.API_BASE_URL}/IntegrantesEventos/GetIntegrantesEventossForCombo?query=${queryParam}`)

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`)
      }

      return await response.json()
    } catch (error) {
      throw error
    }
  },

  // Obtener integrante específico de un evento
  async getIntegranteEvento(eventoId: number, usuarioId: number): Promise<IntegrantesEventos | null> {
    try {
      const queryParam = encodeURIComponent(`x=>x.id_evento==${eventoId} && x.id_usuario==${usuarioId}`)
      const response = await fetch(`${CONFIG.API_BASE_URL}/IntegrantesEventos/GetIntegrantesEventossForCombo?query=${queryParam}`)

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`)
      }

      const integrantes: IntegrantesEventos[] = await response.json()
      return integrantes.length > 0 ? integrantes[0] : null
    } catch (error) {
      throw error
    }
  },

  // Marcar como leído
  async marcarComoLeido(integranteId: number, eventoId: number, usuarioId: number): Promise<void> {
    try {
      const response = await fetch(`${CONFIG.API_BASE_URL}/IntegrantesEventos/UpdateIntegrantesEventos`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: integranteId,
          id_Evento: eventoId,
          id_Usuario: usuarioId,
          leido: true,
          confirmado: false,
        }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Error ${response.status}: ${errorText}`)
      }
    } catch (error) {
      throw error
    }
  },

  // Actualizar confirmación de asistencia
  async actualizarConfirmacion(
    integranteId: number,
    eventoId: number,
    usuarioId: number,
    confirmado: boolean,
  ): Promise<void> {
    try {
      const response = await fetch(`${CONFIG.API_BASE_URL}/IntegrantesEventos/UpdateIntegrantesEventos`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: integranteId,
          id_Evento: eventoId,
          id_Usuario: usuarioId,
          leido: true,
          confirmado: confirmado,
        }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Error ${response.status}: ${errorText}`)
      }
    } catch (error) {
      throw error
    }
  },

  // Enviar correos informativos
  async enviarCorreosInformativos(evento: Evento): Promise<void> {
    try {
      await fetch(`${CONFIG.API_BASE_URL}/Email/EnviarCorreoInformativo`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          eventoId: evento.id,
          nombre: evento.nombre,
          descripcion: evento.descripcion,
          fecha: evento.fecha,
          requiereConfirmacion: evento.requiereConfirmacion,
          tipoDestinatario: evento.tipoDestinatario,
        }),
      })
    } catch (error) {
      console.error("Error enviando correos:", error)
    }
  },

  // Guardar integrantes del evento
  async guardarIntegrantes(eventoId: number, tipoDestinatario: TipoDestinatario): Promise<void> {
    try {
      // Obtener usuarios según el tipo de destinatario
      let queryParam = ""
      switch (tipoDestinatario) {
        case TipoDestinatario.SoloAlumnos:
          queryParam = encodeURIComponent("x=>x.id_perfil==2")
          break
        case TipoDestinatario.SoloPadres:
          queryParam = encodeURIComponent("x=>x.id_perfil==4")
          break
        case TipoDestinatario.Ambos:
        default:
          queryParam = encodeURIComponent("x=>x.id_perfil==2 || x.id_perfil==4")
          break
      }

      const usuariosResponse = await fetch(`${CONFIG.API_BASE_URL}/Usuario/GetUsuariosForCombo?query=${queryParam}`)

      if (!usuariosResponse.ok) {
        throw new Error("Error obteniendo usuarios")
      }

      const usuarios: Usuario[] = await usuariosResponse.json()

      // Crear registro para cada usuario
      for (const usuario of usuarios) {
        await fetch(`${CONFIG.API_BASE_URL}/IntegrantesEventos/CreateIntegrantesEventos`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            id_Evento: eventoId,
            id_Usuario: usuario.id,
            leido: false,
            confirmado: false,
          }),
        })
      }
    } catch (error) {
      throw error
    }
  },

  // Eliminar integrantes del evento
  async eliminarIntegrantesEvento(eventoId: number): Promise<void> {
    try {
      const integrantes = await this.getIntegrantesEvento(eventoId)

      for (const integrante of integrantes) {
        await fetch(`${CONFIG.API_BASE_URL}/IntegrantesEventos/DeleteIntegrantesEventos?id=${integrante.id}`)
      }
    } catch (error) {
      throw error
    }
  },
}

// Función auxiliar para filtrar eventos por perfil
function filtrarEventosPorPerfil(eventos: Evento[], idPerfil: number): Evento[] {
  switch (idPerfil) {
    case 2: // Alumnos
      return eventos.filter(
        (e) => e.tipoDestinatario === TipoDestinatario.SoloAlumnos || e.tipoDestinatario === TipoDestinatario.Ambos,
      )
    case 4: // Padres
      return eventos.filter(
        (e) => e.tipoDestinatario === TipoDestinatario.SoloPadres || e.tipoDestinatario === TipoDestinatario.Ambos,
      )
    default: // Otros perfiles (administradores, docentes)
      return eventos
  }
}
